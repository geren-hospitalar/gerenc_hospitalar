package br.com.sgps.serverSgps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSgpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSgpsApplication.class, args);
	}
}
